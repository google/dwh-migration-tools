Types for Google Cloud Bigquery Migration v2alpha API
=====================================================

.. automodule:: google.cloud.bigquery_migration_v2alpha.types
    :members:
    :undoc-members:
    :show-inheritance:
