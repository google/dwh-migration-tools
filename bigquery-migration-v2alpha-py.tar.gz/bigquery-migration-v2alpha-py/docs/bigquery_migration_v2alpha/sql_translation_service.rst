SqlTranslationService
---------------------------------------

.. automodule:: google.cloud.bigquery_migration_v2alpha.services.sql_translation_service
    :members:
    :inherited-members:
