# -*- coding: utf-8 -*-
# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import proto  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.bigquery.migration.v2alpha',
    manifest={
        'TranslateQueryRequest',
        'TranslateQueryResponse',
        'TranslationResultDetails',
        'TranslationReportRecord',
        'SqlTranslationErrorDetail',
        'SqlTranslationError',
        'SqlTranslationWarning',
    },
)


class TranslateQueryRequest(proto.Message):
    r"""The request of translating a SQL query to Standard SQL.

    Attributes:
        parent (str):
            Required. The name of the project to which this translation
            request belongs. Example: ``projects/foo/locations/bar``
        source_dialect (google.cloud.bigquery_migration_v2alpha.types.TranslateQueryRequest.SqlTranslationSourceDialect):
            Required. The source SQL dialect of ``queries``.
        query (str):
            Required. The query to be translated.
    """
    class SqlTranslationSourceDialect(proto.Enum):
        r"""Supported SQL translation source dialects."""
        SQL_TRANSLATION_SOURCE_DIALECT_UNSPECIFIED = 0
        TERADATA = 1
        REDSHIFT = 2
        ORACLE = 3
        HIVEQL = 4
        SPARKSQL = 5
        SNOWFLAKE = 6
        NETEZZA = 7

    parent = proto.Field(
        proto.STRING,
        number=1,
    )
    source_dialect = proto.Field(
        proto.ENUM,
        number=2,
        enum=SqlTranslationSourceDialect,
    )
    query = proto.Field(
        proto.STRING,
        number=3,
    )


class TranslateQueryResponse(proto.Message):
    r"""The response of translating a SQL query to Standard SQL.

    Attributes:
        translation_job (str):
            Output only. Immutable. The unique identifier for the SQL
            translation job. Example:
            ``projects/123/locations/us/translation/1234``
        translated_query (str):
            The translated result. It may contain
            error/warning messages as comments.
        translation_result_details (google.cloud.bigquery_migration_v2alpha.types.TranslationResultDetails):
            The details of the translation results.
        errors (Sequence[google.cloud.bigquery_migration_v2alpha.types.SqlTranslationError]):
            The list of errors encountered during the
            translation, if present.
        warnings (Sequence[google.cloud.bigquery_migration_v2alpha.types.SqlTranslationWarning]):
            The list of warnings encountered during the
            translation, if present, indicates
            non-semantically correct translation.
    """

    translation_job = proto.Field(
        proto.STRING,
        number=4,
    )
    translated_query = proto.Field(
        proto.STRING,
        number=1,
    )
    translation_result_details = proto.Field(
        proto.MESSAGE,
        number=5,
        message='TranslationResultDetails',
    )
    errors = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message='SqlTranslationError',
    )
    warnings = proto.RepeatedField(
        proto.MESSAGE,
        number=3,
        message='SqlTranslationWarning',
    )


class TranslationResultDetails(proto.Message):
    r"""Translation details like metrics, warning/error records.

    Attributes:
        translation_metrics (Mapping[str, int]):
            Translation metrics. E.g., Compiler_Clean: 5,
            Compiler_BestEffort: 2, Emitter_Clean: 1,Emitter_Error: 3,
            etc.
        report_records (Sequence[google.cloud.bigquery_migration_v2alpha.types.TranslationReportRecord]):
            Translation details about warning/error
            records.
    """

    translation_metrics = proto.MapField(
        proto.STRING,
        proto.INT32,
        number=1,
    )
    report_records = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message='TranslationReportRecord',
    )


class TranslationReportRecord(proto.Message):
    r"""Details about a record.

    Attributes:
        severity (google.cloud.bigquery_migration_v2alpha.types.TranslationReportRecord.Severity):
            Severity of the translation record.
        script_line (int):
            Specifies the row from the source text where
            the error occurred (0 based). Example: 2
        script_column (int):
            Specifies the column from the source texts
            where the error occurred. (0 based) example: 6
        category (str):
            Category of the error/warning. Example:
            SyntaxError
        message (str):
            Detailed message of the record.
    """
    class Severity(proto.Enum):
        r"""The severity type of the record."""
        SEVERITY_UNSPECIFIED = 0
        INFO = 1
        WARNING = 2
        ERROR = 3

    severity = proto.Field(
        proto.ENUM,
        number=1,
        enum=Severity,
    )
    script_line = proto.Field(
        proto.INT32,
        number=2,
    )
    script_column = proto.Field(
        proto.INT32,
        number=3,
    )
    category = proto.Field(
        proto.STRING,
        number=4,
    )
    message = proto.Field(
        proto.STRING,
        number=5,
    )


class SqlTranslationErrorDetail(proto.Message):
    r"""Structured error object capturing the error message and the
    location in the source text where the error occurs.

    Attributes:
        row (int):
            Specifies the row from the source text where
            the error occurred.
        column (int):
            Specifie the column from the source texts
            where the error occurred.
        message (str):
            A human-readable description of the error.
    """

    row = proto.Field(
        proto.INT64,
        number=1,
    )
    column = proto.Field(
        proto.INT64,
        number=2,
    )
    message = proto.Field(
        proto.STRING,
        number=3,
    )


class SqlTranslationError(proto.Message):
    r"""The detailed error object if the SQL translation job fails.

    Attributes:
        error_type (google.cloud.bigquery_migration_v2alpha.types.SqlTranslationError.SqlTranslationErrorType):
            The type of SQL translation error.
        error_detail (google.cloud.bigquery_migration_v2alpha.types.SqlTranslationErrorDetail):
            Specifies the details of the error, including
            the error message and location from the source
            text.
    """
    class SqlTranslationErrorType(proto.Enum):
        r"""The error type of the SQL translation job."""
        SQL_TRANSLATION_ERROR_TYPE_UNSPECIFIED = 0
        SQL_PARSE_ERROR = 1
        UNSUPPORTED_SQL_FUNCTION = 2

    error_type = proto.Field(
        proto.ENUM,
        number=1,
        enum=SqlTranslationErrorType,
    )
    error_detail = proto.Field(
        proto.MESSAGE,
        number=2,
        message='SqlTranslationErrorDetail',
    )


class SqlTranslationWarning(proto.Message):
    r"""The detailed warning object if the SQL translation job is
    completed but not semantically correct.

    Attributes:
        warning_detail (google.cloud.bigquery_migration_v2alpha.types.SqlTranslationErrorDetail):
            Specifies the details of the warning,
            including the warning message and location from
            the source text.
    """

    warning_detail = proto.Field(
        proto.MESSAGE,
        number=1,
        message='SqlTranslationErrorDetail',
    )


__all__ = tuple(sorted(__protobuf__.manifest))
